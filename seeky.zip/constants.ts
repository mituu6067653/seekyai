
export const APP_NAME = 'Seeky';
export const GEMINI_MODEL = 'gemini-2.5-flash';
