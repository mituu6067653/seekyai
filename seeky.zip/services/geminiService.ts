
import { GoogleGenAI, Chat } from "@google/genai";
import { GEMINI_MODEL } from '../constants';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const createChat = (): Chat => {
    return ai.chats.create({
        model: GEMINI_MODEL,
        config: {
            systemInstruction: 'You are Seeky, a helpful and friendly AI assistant. Your responses should be concise, informative, and engaging.',
        },
    });
};
