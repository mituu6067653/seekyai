
import React from 'react';
import { APP_NAME } from '../constants';
import { BotIcon } from './icons';

const Header: React.FC = () => {
    return (
        <header className="sticky top-0 z-10 bg-slate-800/50 backdrop-blur-lg border-b border-slate-700">
            <div className="container mx-auto px-4 py-3 flex items-center gap-3">
                <BotIcon className="w-7 h-7 text-blue-400" />
                <h1 className="text-xl font-bold text-slate-200">{APP_NAME}</h1>
            </div>
        </header>
    );
};

export default Header;
