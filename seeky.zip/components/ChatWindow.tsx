
import React, { useEffect, useRef } from 'react';
import { type Message, Sender } from '../types';
import MessageBubble from './MessageBubble';

interface ChatWindowProps {
    messages: Message[];
    isLoading: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isLoading]);

    return (
        <main className="flex-1 overflow-y-auto p-4 space-y-6">
            <div className="flex flex-col space-y-4">
                {messages.map((message, index) => {
                    const isStreaming = 
                        isLoading && 
                        index === messages.length - 1 && 
                        message.sender === Sender.AI;

                    return (
                        <MessageBubble 
                            key={message.id} 
                            message={message} 
                            isStreaming={isStreaming}
                        />
                    );
                })}
                <div ref={messagesEndRef} />
            </div>
        </main>
    );
};

export default ChatWindow;
