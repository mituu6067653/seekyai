import React, { useState, useEffect } from 'react';
import { type Message, Sender } from '../types';
import { BotIcon, UserIcon, Volume2Icon } from './icons';

interface MessageBubbleProps {
    message: Message;
    isStreaming?: boolean;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isStreaming = false }) => {
    const [displayedText, setDisplayedText] = useState('');
    // Adjusted typing speed for a faster feel, interpreting "0.15x" as a request for more speed.
    // A lower value is faster. 20ms is a 1.5x speed-up from the previous 30ms.
    const TYPING_SPEED = 20; // ms per character

    useEffect(() => {
        if (isStreaming && message.sender === Sender.AI) {
            // Reset if the stream provides text that doesn't start with what's already displayed.
            // This handles the transition from loading dots (empty text) to the first chunk.
            if (displayedText.length > 0 && !message.text.startsWith(displayedText)) {
                setDisplayedText('');
                return;
            }

            if (displayedText.length < message.text.length) {
                const timeoutId = setTimeout(() => {
                    setDisplayedText(message.text.substring(0, displayedText.length + 1));
                }, TYPING_SPEED);
                return () => clearTimeout(timeoutId);
            }
        } else {
            // Not streaming or not an AI message, so display the full text immediately.
            if (displayedText !== message.text) {
                setDisplayedText(message.text);
            }
        }
    }, [displayedText, message.text, isStreaming, message.sender]);

    const isUser = message.sender === Sender.User;

    const handleTextToSpeech = () => {
        if ('speechSynthesis' in window && message.text && !isStreaming) {
            const utterance = new SpeechSynthesisUtterance(message.text);
            window.speechSynthesis.speak(utterance);
        }
    };

    const bubbleClasses = isUser
        ? 'bg-blue-600 text-white rounded-br-none'
        : 'bg-slate-700 text-slate-200 rounded-bl-none';

    const containerClasses = isUser ? 'items-end' : 'items-start';
    const contentClasses = isUser ? 'flex-row-reverse' : 'flex-row';

    const formatText = (text: string) => {
        const html = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br />');
        return { __html: html };
    };

    const textToRender = message.sender === Sender.AI ? displayedText : message.text;

    // The loading dots should show ONLY when message.text is empty.
    const showLoadingDots = message.sender === Sender.AI && !message.text;

    return (
        <div className={`flex flex-col ${containerClasses}`}>
            <div className={`flex gap-3 max-w-xl ${contentClasses}`}>
                <div className="flex-shrink-0">
                    {isUser ? (
                        <div className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center">
                            <UserIcon className="w-5 h-5 text-slate-300" />
                        </div>
                    ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center">
                            <BotIcon className="w-5 h-5 text-blue-400" />
                        </div>
                    )}
                </div>
                <div className={`px-4 py-3 rounded-xl ${bubbleClasses}`}>
                    {showLoadingDots ? (
                        <div className="flex items-center justify-center space-x-1">
                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></span>
                        </div>
                    ) : (
                        <p className="text-base leading-relaxed min-h-[1.5rem]">
                            <span dangerouslySetInnerHTML={formatText(textToRender)} />
                            {isStreaming && message.sender === Sender.AI && (
                                <span className="inline-block w-2 h-5 bg-slate-300 animate-pulse ml-1 translate-y-1" aria-hidden="true" />
                            )}
                        </p>
                    )}
                </div>
                {!isUser && message.text && !isStreaming && (
                    <button
                        onClick={handleTextToSpeech}
                        className="self-center text-slate-400 hover:text-blue-400 transition-colors"
                        aria-label="Read message aloud"
                    >
                        <Volume2Icon className="w-5 h-5" />
                    </button>
                )}
            </div>
        </div>
    );
};

export default MessageBubble;
